import cv2
import numpy as np
from PIL import Image
import os
from keras.models import Sequential
from keras.layers import Activation
from keras.layers.core import Dense,Flatten,Dropout
from keras.optimizers import Adam
from keras.metrics import categorical_crossentropy
from keras.layers.convolutional import *
from keras.utils import to_categorical
from keras.utils import np_utils

def preparing_data():

    base_dir= os.path.dirname(os.path.abspath(__file__))
    image_dir=os.path.join(base_dir,"D:\Thesis Experiments\Keras\yalefaces")

    face_cascade=cv2.CascadeClassifier("D:\Thesis Experiments\lbpcascade_frontalface.xml")


    current_id=0
    label_ids={}
    y_labels=[]
    x_train=[]

    for root,dirs,files in os.walk(image_dir):
        for file in files:
            if file.endswith("jpg") or file.endswith("gif"):
                path=os.path.join(root,file)
                #print(path)
                label=os.path.basename(root).replace(" ","-").lower()
                #print(label,path)
                if not label in label_ids:
                    label_ids[label]=current_id
                    current_id+=1
                id_=np.array(label_ids[label],"uint8")
                #print(label_ids)
                pil_image=Image.open(path).convert("L")
                image_array=np.array(pil_image,"uint8")
                #image_array = image_array.reshape(image_array.shape + (1,))
                #print(image_array)
                #print(pil_image.format, pil_image.size, pil_image.mode)
                faces=face_cascade.detectMultiScale(image_array,scaleFactor=1.05, minNeighbors=4)
                for(x,y,w,h) in faces:
                    roi=image_array[y:y+h,x:x+w]
                    roi = cv2.resize(roi, (160, 160))
                    #roi=roi.reshape(roi.shape+(1,))
                    x_train.append(roi)
                    y_labels.append(id_)

    x_train1=np.array(x_train)
    x_train1=x_train1.astype('float32')
    x_train1/=255
    x_train1=np.expand_dims(x_train1,axis=4)
    #print(x_train1.shape)
    #print(numOfSamples)

    y_labels=np_utils.to_categorical(y_labels,15)
    print(y_labels)

    return x_train1,y_labels

xdata,ydata=preparing_data()


####################KFold Validation
def kFold_Val(dsx,dsy, folds):
    tpr=fpr=0
   # tplist=list()
    #fplist=list()
    classes=15
    for k in range(int(folds)):
        model = Sequential()
        print("Fold No: ", k)
        trainingX = [x for i, x in enumerate(dsx) if not i % folds == k]
        trainingY = [x for i, x in enumerate(dsy) if not i % folds == k]

        #trainlist.append(len(trainingX))
        print("Model Trained by, ",len(trainingX)," images and ",len(trainingY)," labels")
        testingX = [x for i, x in enumerate(dsx) if i % folds == k]
        testingY = [x for i, x in enumerate(dsy) if i % folds == k]
        print("Model Tested by, ", len(testingX), " images ")
        model.add(Conv2D(32,(3,3), input_shape=(160,160,1), activation='relu'))
        model.add(MaxPooling2D(pool_size=(2, 2)))
        model.add(Conv2D(32, (3, 3), activation='relu'))
        model.add(MaxPooling2D(pool_size=(2, 2)))
        model.add(Flatten())
        model.add(Dense(32, activation='relu'))
        model.add(Dense(32, activation='relu'))
        #model.add(Dropout(0.5))
        model.add(Dense(15,activation='softmax'))
        model.compile(Adam(lr=.0001), loss='categorical_crossentropy', metrics=['accuracy'])
        model.summary()

        j = 0
        for i in trainingX:
            #print(i)
            b = trainingY[j]
            #print(b)
            #roi=roi.reshape(roi.shape+(1,))
            i=i.reshape((1,)+i.shape)
            b = b.reshape((1,) + b.shape)
            #print("image", i," labels: ",b)
            model.fit(i,b)
            #print("training", i, " labels ", trainingY[j])
            j=j+1



    #model.weights=" "
        for idx, c in enumerate(testingX):
            c = c.reshape((1,) + c.shape)
            #lbl=testingY[idx]
            #lbl=lbl.reshape((1,) + lbl.shape)
            idt= model.predict_classes(c)
            print("Identity: ",idt," Labels ",testingY[idx])
            #if idt == lbl:
             #   tpr = tpr + 1
            #lse:
              #  fpr = fpr + 1
        #print("True positives: ",tpr," False Positives: ",fpr)
        #tpr=fpr=0
kFold_Val(xdata,ydata,10)





