import numpy as np
from PIL import Image
import cv2
import pickle
import os
#FaceDS contain 5 folders each folder with 18 images.
def preparing_data():

    base_dir= os.path.dirname(os.path.abspath(__file__))
    image_dir=os.path.join(base_dir,"faceDS")

    face_cascade=cv2.CascadeClassifier("lbpcascade_frontalface.xml")
    face_recognizer=cv2.face.LBPHFaceRecognizer_create()

    current_id=0
    label_ids={}
    y_labels=[]
    x_train=[]

    for root,dirs,files in os.walk(image_dir):
        for file in files:
            if file.endswith("jpg") or file.endswith("png"):
                path=os.path.join(root,file)
            #print(path)
                label=os.path.basename(root).replace(" ","-").lower()
            #print(label,path)
                if not label in label_ids:
                    label_ids[label]=current_id
                    current_id+=1
                id_=label_ids[label]
            #print(label_ids)
                pil_image=Image.open(path).convert("L")
                image_array=np.array(pil_image,"uint8")
                faces=face_cascade.detectMultiScale(image_array,scaleFactor=1.3, minNeighbors=5)
                for(x,y,w,h) in faces:
                    roi=image_array[y:y+h,x:x+w]
                    x_train.append(roi)
                    y_labels.append(id_)
    with open("labls.pickle", 'wb') as f:
        pickle.dump(label_ids, f)

    return x_train,y_labels

xdata,ydata=preparing_data()
########################################################################
#######################################################################
#######################################################################
with open("labls.pickle",'rb') as f:
    original_labels=pickle.load(f)
    labels={v:k for k,v in original_labels.items()}

face_recognizer=cv2.face.LBPHFaceRecognizer_create()

def kFold_Val(dsx,dsy, folds):
    tpr=tnr=0
    tplist=list()
    tnlist=list()
    for k in range(int(folds)):
        print("Fold No: ", k)
        trainingX = [x for i, x in enumerate(dsx) if not i % folds == k]
        trainingY = [x for i, x in enumerate(dsy) if not i % folds == k]
        face_recognizer.train(trainingX, np.array(trainingY))
        print("Model Trained by, ",len(trainingX)," images and ",len(trainingY)," labels")
        testing = [x for i, x in enumerate(dsx) if i % folds == k]
        for c in testing:
            idt,conf = face_recognizer.predict(c)
            if conf<50:
                tpr=tpr+1
            else:
                tnr=tnr+1
        print("Model Tested with fold size: i.e ", len(testing)," with folloing True Positive and True Negative Results")
        print("tp: ",tpr," tn: ",tnr)
        tplist.append(tpr)
        tnlist.append(tnr)
        tpr=tnr=0


    return tplist,tnlist

#Calling Kfold_val function which return list of all Tpositive and Tnegative on which we can perform other operations
TPlist= list()
TNlist=list()
TPlist,TNlist=kFold_Val(xdata,ydata, 10)
print(TPlist)
print(TNlist)



